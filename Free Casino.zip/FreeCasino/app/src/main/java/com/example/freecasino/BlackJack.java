package com.example.freecasino;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.Collections;

public class BlackJack extends AppCompatActivity {

    TextView puntosIA,resIA,partidasJug,ganadas,perdidas;
    ImageView j1,j2,j3,j4,j5,j6,i1,i2,i3,i4,i5,i6;
    Button pedirC,plant;
    ImageButton volver;
    String[] cartas;
    int cont = 0, puntuacionJug=0,puntuacionIA=0,gana=0;
    boolean plantado=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_jack);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);//orientacion de pantalla

        cartas = new String[]{"p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "px", "pj", "pq", "pk",
                "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "cx", "cj", "cq", "ck",
                "t1", "t2", "t3", "t4", "t5", "t6", "t7", "t8", "t9", "tx", "tj", "tq", "tk",
                "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "dx", "dj", "dq", "dk"}
        ;
        //mezclamos el array
        Collections.shuffle(Arrays.asList(cartas));

        //definimos objetos a usar
        pedirC = findViewById(R.id.pedirCarta);
        plant = findViewById(R.id.plantarse);
        volver = findViewById(R.id.volverBtn);
        partidasJug = findViewById(R.id.partidasHelp);
        ganadas = findViewById(R.id.ganadasHelp);
        perdidas = findViewById(R.id.perdidasHelp);

        //poner de los strings cuantas partidas llevas
        SharedPreferences pref = getSharedPreferences(getString(R.string.partidasJug), Context.MODE_PRIVATE);

        String partJug = pref.getString("partJug","0");
        partidasJug.setText(partJug);

        //poner las ganadas
        pref = getSharedPreferences(getString(R.string.partidasGan), Context.MODE_PRIVATE);

        String gan = pref.getString("partGan","0");
        ganadas.setText(gan);

        //poner las perdidas
        pref = getSharedPreferences(getString(R.string.partidasPer), Context.MODE_PRIVATE);

        String per = pref.getString("partPer","0");
        perdidas.setText(per);

        //cartas view
        j1 = findViewById(R.id.Jcarta1);
        j2 = findViewById(R.id.Jcarta2);
        j3 = findViewById(R.id.Jcarta3);
        j4 = findViewById(R.id.Jcarta4);
        j5 = findViewById(R.id.Jcarta5);
        j6 = findViewById(R.id.Jcarta6);

        i1 = findViewById(R.id.Icarta1);
        i2 = findViewById(R.id.Icarta2);
        i3 = findViewById(R.id.Icarta3);
        i4 = findViewById(R.id.Icarta4);
        i5 = findViewById(R.id.Icarta5);
        i6 = findViewById(R.id.Icarta6);


        plant.setOnClickListener(this::plnt);
        pedirC.setOnClickListener(this::juego);
        //nuevoJ.setOnClickListener(this::nuevoJu);
        volver.setOnClickListener(this::home);

    }

    public void juego(View view) {
        if(puntuacionJug <= 21 && plantado==false) {
            String ima = cartas[cont];
            int resID = getResources().getIdentifier(ima, "drawable", getPackageName());
            if(j1.getDrawable() == null) {
                j1.setImageResource(resID);
            } else if (j2.getDrawable() == null) {
                j2.setImageResource(resID);
            } else if (j3.getDrawable() == null) {
                j3.setImageResource(resID);
            } else if (j4.getDrawable() == null) {
                j4.setImageResource(resID);
            } else if (j5.getDrawable() == null) {
                j5.setImageResource(resID);
            } else if (j6.getDrawable() == null) {
                j6.setImageResource(resID);
            }

            puntuacionJug += puntos();
        }
    }

    public void plnt(View view){
        if(!plantado && puntuacionJug > 0) {
            plantado = true;
            juegoIA();
        }

    }

    public void juegoIA(){
        boolean seguir=true;
        while(seguir){
            if((puntuacionIA>=18 || puntuacionIA > puntuacionJug)|| (puntuacionJug > 21 && puntuacionIA >0)){
                seguir=false;
            }else{
                String ima = cartas[cont];
                int resID = getResources().getIdentifier(ima, "drawable", getPackageName());
                if (i1.getDrawable() == null) {
                    i1.setImageResource(resID);
                } else if (i2.getDrawable() == null) {
                    i2.setImageResource(resID);
                } else if (i3.getDrawable() == null) {
                    i3.setImageResource(resID);
                } else if (i4.getDrawable() == null) {
                    i4.setImageResource(resID);
                } else if (i5.getDrawable() == null) {
                    i5.setImageResource(resID);
                } else if (i6.getDrawable() == null) {
                    i6.setImageResource(resID);
                }

                puntuacionIA += puntos();
            }
        }
        if(!seguir) {
            resultados();
        }

    }

    public void resultados(){
        if((puntuacionJug > puntuacionIA && puntuacionJug <=21) || (puntuacionIA > 21 && puntuacionJug <=21)){
            Toast.makeText(getApplicationContext(), getString(R.string.msgGana), Toast.LENGTH_SHORT).show();
            gana=1;
        }if((puntuacionIA > puntuacionJug && puntuacionIA <=21) || (puntuacionJug > 21 && puntuacionIA <=21)){
            Toast.makeText(getApplicationContext(), getString(R.string.msgPier), Toast.LENGTH_SHORT).show();
            gana=0;
        } if (puntuacionIA == puntuacionJug && puntuacionIA <=21 && puntuacionJug <=21) {
            Toast.makeText(getApplicationContext(), getString(R.string.msgEmp), Toast.LENGTH_SHORT).show();
            gana=2;
        }
    }

    public int puntos(){
        int devolver=0;
        String punto = cartas[cont].substring(1,2);

        if(punto.equals("x")||punto.equals("j")||punto.equals("q")||punto.equals("k")){
            devolver=10;
        }else if(cont==0 && punto.equals("1")){
            devolver=11;
        }else{
            devolver=Integer.parseInt(punto);
        }
        cont++;
        return devolver;
    }


    public void home (View view){
        Intent i = new Intent(this, MainActivity.class);




        if(gana==0){
            SharedPreferences pref = getSharedPreferences(getString(R.string.partidasPer), Context.MODE_PRIVATE);

            SharedPreferences.Editor editor = pref.edit();

            //incrementa a 1
            String cont = perdidas.getText().toString();
            int val = Integer.parseInt(cont);
            val++;

            editor.putString("partPer", String.valueOf(val));

            editor.apply();

        }else if(gana==1){

            SharedPreferences pref = getSharedPreferences(getString(R.string.partidasGan), Context.MODE_PRIVATE);

            SharedPreferences.Editor editor = pref.edit();

            //incrementa a 1
            String cont = ganadas.getText().toString();
            int val = Integer.parseInt(cont);
            val++;

            editor.putString("partGan", String.valueOf(val));

            editor.apply();

        }


        startActivity(i);
        finish();
    }
}